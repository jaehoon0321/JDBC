create
    definer = root@localhost procedure SP_MEMBER_INSERT(IN V_USERID varchar(20), IN V_PWD varchar(20),
                                                        IN V_EMAIL varchar(50), IN V_HP varchar(20), OUT RTN_CODE int)
BEGIN
    DECLARE v_count int;

    SELECT COUNT(m_seq) into v_count FROM TB_MEMBER WHERE M_USERID = V_USERID;

    IF v_count > 0 THEN
        SET RTN_CODE = 100;
    ELSE
        INSERT INTO TB_MEMBER (M_USERID, M_pwd, M_EMAIL,M_HP)
        VALUES (V_USERID,V_PWD,V_EMAIL,V_HP);
        SET RTN_CODE = 200;
    END IF;
    COMMIT;
end;

