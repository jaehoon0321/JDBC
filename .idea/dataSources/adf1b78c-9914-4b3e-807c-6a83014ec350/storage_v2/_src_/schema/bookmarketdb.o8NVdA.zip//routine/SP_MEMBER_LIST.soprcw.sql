create
    definer = root@localhost procedure SP_MEMBER_LIST()
BEGIN
    SELECT
        m_seq,
        m_userid,
        m_pwd,
        m_email,
        m_hp,
        m_registdate,
        m_point
    FROM TB_MEMBER;
END;

