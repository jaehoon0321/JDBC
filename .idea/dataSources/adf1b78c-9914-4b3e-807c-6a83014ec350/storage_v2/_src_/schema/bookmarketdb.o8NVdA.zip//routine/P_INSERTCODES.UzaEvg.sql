create
    definer = root@localhost procedure P_INSERTCODES(IN cData varchar(255), IN cTname varchar(255),
                                                     OUT resultMsg varchar(255))
BEGIN
    SET @strsql = CONCAT(
            'INSERT INTO ', cTname, '(cid, cname)',
            ' SELECT COALESCE(MAX(cid),0)+1, ? FROM ', cTname
                  );

    SET @cData = cData;
    SET resultMsg = 'Insert Sucess!';

    prepare stmt FROM @strSql;
    EXECUTE stmt USING @cData;

    DEALLOCATE PREPARE stmt;
    COMMIT;
END;

